A2DP Windows Bridge 2.0.2-beta.5 diagnostic bundle, 20261022_000545

diagnostics.txt  the diagnostic info (as copied from Diagnostics)
system.txt       Windows, USB Bluetooth adapters and drivers, paired devices, audio endpoints
logs/            log files: a2dpwb-core (the service), a2dpwb-ui (the window), a2dpwb-driver (driver changes)
config/          settings, profiles, known devices (no link keys)
crash/           crash reports: .txt, and .dmp minidumps for Visual Studio / WinDbg
hci/             HCI captures (.pklg) for Wireshark: recorder-* is the flight recorder at the time of
this bundle, hci-* were saved when a stream failed. Media payloads are cut short
and pairing keys zeroed; captures started by hand are not included (they keep them)

Bluetooth addresses: masked in the text files (AA:BB:CC:xx:xx:xx)
HCI captures: they contain the full Bluetooth addresses (not the pairing keys)
